// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2');
const path = require('path');

// Configuração do MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'ifsp',
  database: 'projeto2024'
});

// Conectar ao banco de dados
db.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conexão ao banco de dados estabelecida com sucesso.');
  }
});

// Configuração do servidor Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const PORT = 5000;

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Rota para servir os arquivos HTML dos chats
app.get('/chatFisicas', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatFisicas.html'));
});

app.get('/chatIntelectuais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatIntelectuais.html'));
});

app.get('/chatSensoriais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatSensoriais.html'));
});

app.get('/chatNeuroDivergentes', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatNeuroDivergentes.html'));
});

// Função para carregar mensagens anteriores de uma tabela específica
const loadPreviousMessages = (socket, tableName) => {
  const selectMessagesQuery = `SELECT * FROM ${tableName}`;
  db.query(selectMessagesQuery, (err, results) => {
    if (err) {
      console.error(`Erro ao buscar mensagens anteriores da tabela ${tableName}:`, err);
    } else {
      socket.emit('previousMessages', results);
    }
  });
};

// Função para inserir nova mensagem em uma tabela específica
const insertNewMessage = (socket, tableName, data) => {
  const { name, message } = data;
  const insertMessageQuery = `INSERT INTO ${tableName} (name, message) VALUES (?, ?)`;
  db.query(insertMessageQuery, [name, message], (err, result) => {
    if (err) {
      console.error(`Erro ao adicionar mensagem na tabela ${tableName}:`, err);
    } else {
      const newMessage = { id: result.insertId, name, message };
      socket.broadcast.emit('newMessage', newMessage);
      socket.emit('newMessage', newMessage);
    }
  });
};

// Conexão do Socket.IO
io.on('connection', (socket) => {
  console.log('Usuário conectado');

  // Eventos para diferentes chats
  socket.on('joinChatFisicas', () => {
    loadPreviousMessages(socket, 'msgfisicas');
  });

  socket.on('joinChatIntelectuais', () => {
    loadPreviousMessages(socket, 'msgintelectuais');
  });

  socket.on('joinChatSensoriais', () => {
    loadPreviousMessages(socket, 'msgsensoriais');
  });

  socket.on('joinChatNeuroDivergentes', () => {
    loadPreviousMessages(socket, 'msgneurodivergentes');
  });

  // Receber nova mensagem
  socket.on('sendMessageFisicas', (data) => {
    insertNewMessage(socket, 'msgfisicas', data);
  });

  socket.on('sendMessageIntelectuais', (data) => {
    insertNewMessage(socket, 'msgintelectuais', data);
  });

  socket.on('sendMessageSensoriais', (data) => {
    insertNewMessage(socket, 'msgsensoriais', data);
  });

  socket.on('sendMessageNeuroDivergentes', (data) => {
    insertNewMessage(socket, 'msgneurodivergentes', data);
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado');
  });
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.get("/fisica", (req, res) => {
  res.sendFile(__dirname + "/public/fisica/index.html");
});

app.get("/neurodivergente", (req, res) => {
  res.sendFile(__dirname + "/public/neurodivergente/index.html");
});

app.get("/sensorial", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/index.html");
});

app.get("/intelectual", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/index.html");
});

app.get("/fisica/amputacao", (req, res) => {
  res.sendFile(__dirname + "/public/fisica/amp.html");
});

app.get("/fisica/nanismo", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/nanismo.html");
});

app.get("/fisica/plagia", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/plagia.html");
});

app.get("/fisica/poliomielite", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/poliomielite.html");
});

app.get("/neurodivergente/tdah", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/tdah.html");
});

app.get("/neurodivergente/autismo", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/autismo.html");
});

app.get("/neurodivergente/dislexia", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/dislexia.html");
});

app.get("/sensorial/cegueira", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/cegueira.html");
});

app.get("/sensorial/surdez", (req, res) => {
  res.sendFile(__dirname + "/public/sensorial/surdez.html");
});

app.get("/intelectual/sindromededown", (req, res) => {
  res.sendFile(__dirname + "/public/intelectual/sindromededown.html");
});

app.get("/intelectual/sindromedocri", (req, res) => {
  res.sendFile(__dirname + "/public/intelectual/sindromedocri.html");
});

app.get("/intelectual/sindromedeangelman", (req, res) => {
  res.sendFile(__dirname + "/public/intelectual/sindromedeangelman.html");
});

app.get("/intelectual/sindromedewillians", (req, res) => {
  res.sendFile(__dirname + "/public/intelectual/sindromedewillians.html");
});

// Iniciar o servidor
server.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});