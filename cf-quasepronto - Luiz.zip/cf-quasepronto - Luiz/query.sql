CREATE DATABASE projeto2024;
USE projeto2024;

CREATE TABLE msgfisicas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    message TEXT
);
CREATE TABLE msgintelectuais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    message TEXT
);
CREATE TABLE msgsensoriais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    message TEXT
);
CREATE TABLE msgneurodivergentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    message TEXT
);