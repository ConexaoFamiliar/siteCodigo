// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2');
const path = require('path');

// Configuração do MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'projeto2024'
});

// Conectar ao banco de dados
db.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conexão ao banco de dados estabelecida com sucesso.');
  }
});

// Configuração do servidor Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const PORT = 5000;

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public/cadastro')));
app.use(express.static(path.join(__dirname, 'chats')));

// Rota para servir os arquivos HTML dos chats
app.get('/chatFisicas', (req, res) => {
  res.sendFile(path.join(__dirname, 'chats/chatFisicas.html'));
});

app.get('/chatIntelectuais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chats/chatIntelectuais.html'));
});

app.get('/chatSensoriais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chats/chatSensoriais.html'));
});

app.get('/chatNeuroDivergentes', (req, res) => {
  res.sendFile(path.join(__dirname, 'chats/chatNeuroDivergentes.html'));
});

// Função para carregar mensagens anteriores de uma tabela específica
const loadPreviousMessages = (socket, tableName, userId) => {
  const selectMessagesQuery = `SELECT msg.id, msg.message, u.nome AS name FROM ${tableName} msg JOIN users u ON msg.user_id = u.id WHERE msg.user_id = ?`;
  db.query(selectMessagesQuery, [userId], (err, results) => {
    if (err) {
      console.error(`Erro ao buscar mensagens anteriores da tabela ${tableName}:`, err);
    } else {
      socket.emit('previousMessages', results);
    }
  });
};

// Função para inserir nova mensagem em uma tabela específica
const insertNewMessage = (socket, tableName, data, userId, userName) => {
  const { message } = data;
  const insertMessageQuery = `INSERT INTO ${tableName} (message, user_id) VALUES (?, ?)`;
  db.query(insertMessageQuery, [message, userId], (err, result) => {
    if (err) {
      console.error(`Erro ao adicionar mensagem na tabela ${tableName}:`, err);
    } else {
      const newMessage = { id: result.insertId, message, name: userName };
      io.emit('newMessage', newMessage); // Envia a mensagem para todos os clientes
    }
  });
};

// Função para verificar CPF e obter informações do usuário
const getUserByCpf = (cpf, callback) => {
  const query = 'SELECT * FROM users WHERE cpf = ?';
  db.query(query, [cpf], (err, results) => {
    if (err) {
      callback(err, null);
    } else if (results.length === 0) {
      callback(null, null);
    } else {
      callback(null, results[0]);
    }
  });
};

// Conexão do Socket.IO
io.on('connection', (socket) => {
  console.log('Usuário conectado');

  // Verificar CPF ao entrar no chat
  socket.on('joinChatFisicas', (cpf) => {
    getUserByCpf(cpf, (err, user) => {
      if (err) {
        console.error('Erro ao buscar CPF:', err);
        socket.emit('cpfInvalid');
      } else if (user) {
        socket.userId = user.id;
        socket.userName = user.nome;
        socket.emit('cpfValid', { name: user.nome });
        loadPreviousMessages(socket, 'msgfisicas', user.id);
      } else {
        socket.emit('cpfInvalid');
      }
    });
  });

  // Receber nova mensagem
  socket.on('sendMessageFisicas', (data) => {
    if (socket.userId) {
      insertNewMessage(socket, 'msgfisicas', data, socket.userId, socket.userName);
    }
  });

  // Receber nova mensagem para msgintelectuais
  socket.on('sendMessageIntelectuais', (data) => {
    if (socket.userId) {
      insertNewMessage(socket, 'msgintelectuais', data, socket.userId, socket.userName);
    }
  });

  // Receber nova mensagem para msgsensoriais
  socket.on('sendMessageSensoriais', (data) => {
    if (socket.userId) {
      insertNewMessage(socket, 'msgsensoriais', data, socket.userId, socket.userName);
    }
  });

  // Receber nova mensagem para msgneurodivergentes
  socket.on('sendMessageNeuroDivergentes', (data) => {
    if (socket.userId) {
      insertNewMessage(socket, 'msgneurodivergentes', data, socket.userId, socket.userName);
    }
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado');
  });
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.get("/cad", (req, res) => {
  res.sendFile(__dirname + "/public/cadastro/index.html");
});

app.get('/cadPost', (req, res) => {
  const nome = req.query.nome;
  const cpf = req.query.cpf;

  const sql = `INSERT INTO users(nome, cpf) VALUES('${nome}', '${cpf}')`;

  db.query(sql, (erro) => {
    if(erro) {
      res.send("<h2>Falha ao realizar cadastro</h2>" + erro);
    }
    else {
      res.redirect("/cad");
    }
  });
});

// Outras rotas...

// Iniciar o servidor
server.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});