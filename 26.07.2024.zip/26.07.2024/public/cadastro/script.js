const checkForm = {
    nome: false,
    cpf: false
};

document.getElementById("nome").addEventListener("input", (e) => {
    const nome = e.target.value;
    if(nome.length < 3 || nome.length > 50) {
        document.getElementById("nomeerro").style.display = "block";
        checkForm.nome = false;
    }
    else {
        document.getElementById("nomeerro").style.display = "none";
        checkForm.nome = true;
    }
    checkButton();
});

document.getElementById("cpf").addEventListener("input", (e) => {
    const cpf = e.target.value;
    if(cpf.length != 11) {
        document.getElementById("cpferro").style.display = "block";
        checkForm.cpf = false;
    }
    else {
        document.getElementById("cpferro").style.display = "none";
        checkForm.cpf = true;
    }
    checkButton();
});

const checkButton = () => {
    let enable = true;

    Object.keys(checkForm).forEach(key => {
        if(!checkForm[key]) {
            enable = false;
        }
    });

    document.getElementById("button").disabled = !enable;
}