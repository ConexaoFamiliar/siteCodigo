// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2');
const path = require('path');

// Configuração do MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'ifsp',
  database: 'projeto2024'
});

// Conectar ao banco de dados
db.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conexão ao banco de dados estabelecida com sucesso.');
  }
});

// Configuração do servidor Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const PORT = 5000;

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Rota para servir os arquivos HTML dos chats
app.get('/chatFisicas', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatFisicas.html'));
});

app.get('/chatIntelectuais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatIntelectuais.html'));
});

app.get('/chatSensoriais', (req, res) => {
  res.sendFile(path.join(__dirname, 'chatSensoriais.html'));
});

// Função para carregar mensagens anteriores de uma tabela específica
const loadPreviousMessages = (socket, tableName) => {
  const selectMessagesQuery = `SELECT * FROM ${tableName}`;
  db.query(selectMessagesQuery, (err, results) => {
    if (err) {
      console.error(`Erro ao buscar mensagens anteriores da tabela ${tableName}:`, err);
    } else {
      socket.emit('previousMessages', results);
    }
  });
};

// Função para inserir nova mensagem em uma tabela específica
const insertNewMessage = (socket, tableName, data) => {
  const { name, message } = data;
  const insertMessageQuery = `INSERT INTO ${tableName} (name, message) VALUES (?, ?)`;
  db.query(insertMessageQuery, [name, message], (err, result) => {
    if (err) {
      console.error(`Erro ao adicionar mensagem na tabela ${tableName}:`, err);
    } else {
      const newMessage = { id: result.insertId, name, message };
      socket.broadcast.emit('newMessage', newMessage);
      socket.emit('newMessage', newMessage);
    }
  });
};

// Conexão do Socket.IO
io.on('connection', (socket) => {
  console.log('Usuário conectado');

  // Eventos para diferentes chats
  socket.on('joinChatFisicas', () => {
    loadPreviousMessages(socket, 'msgfisicas');
  });

  socket.on('joinChatIntelectuais', () => {
    loadPreviousMessages(socket, 'msgintelectuais');
  });

  socket.on('joinChatSensoriais', () => {
    loadPreviousMessages(socket, 'msgsensoriais');
  });

  // Receber nova mensagem
  socket.on('sendMessageFisicas', (data) => {
    insertNewMessage(socket, 'msgfisicas', data);
  });

  socket.on('sendMessageIntelectuais', (data) => {
    insertNewMessage(socket, 'msgintelectuais', data);
  });

  socket.on('sendMessageSensoriais', (data) => {
    insertNewMessage(socket, 'msgsensoriais', data);
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado');
  });
});


app.get("/amputacao", (req, res) => {
  res.sendFile(__dirname + "/public/doencas/amputacao.html")
});

app.get("/nanismo", (req, res) => {
  res.sendFile(__dirname + "/public/doencas/nanismo.html")
});

app.get("/plagia", (req, res) => {
  res.sendFile(__dirname + "/public/doencas/plagia.html")
});

app.get("/poliomelite", (req, res) => {
  res.sendFile(__dirname + "/public/doencas/poliomelite.html")
});

// Iniciar o servidor
server.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});